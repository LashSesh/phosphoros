# Satanael.lite

Satanael.lite is a pure Rust re-imagination of the AinSOFT forensic stack. It
provides a high-dimensional analytics pipeline and a satellite-style API service
that blockchain security teams can integrate to triangulate anomalous wallet or
contract activity across distributed ledgers.

## Features

- **High-dimensional resonance analytics** using vector geometry, clustering and
topological heuristics implemented with `ndarray` and `petgraph`.
- **Deterministic ingestion pipeline** that normalises entity vectors and keeps a
bounded archive of recent blockchain snapshots.
- **Axum-based API service** exposing ingestion, analysis, and reporting
endpoints suitable for integration with external threat-intelligence systems.
- **Configurable orchestration** via YAML or JSON configuration files supporting
network deployment without recompilation.
- **Pure Rust implementation** with no Python runtime dependencies.

## Running the service

```bash
cargo run --release
```

By default the service binds to `0.0.0.0:8080`. Set the `SATANAEL_CONFIG`
environment variable to point at a YAML/JSON configuration file to customise the
listener, analysis parameters, and retention settings.

## API quickstart

1. **Ingest a snapshot**

   ```bash
   curl -X POST http://localhost:8080/v1/snapshots \
        -H 'Content-Type: application/json' \
        -d '{
              "label": "demo",
              "observations": [
                {
                  "id": "00000000-0000-0000-0000-000000000001",
                  "address": "0xdeadbeef",
                  "features": [0.1, 0.2, 0.3, 0.4, 0.5]
                }
              ]
            }'
   ```

2. **Trigger an analysis**

   ```bash
   curl -X POST http://localhost:8080/v1/analyze/<snapshot_id> \
        -H 'Content-Type: application/json' \
        -d '{"knn_k": 6, "resonance_threshold": 0.7}'
   ```

3. **Retrieve the latest report**

   ```bash
   curl http://localhost:8080/v1/reports/latest
   ```

## Testing

```bash
cargo test
```

## License

Dual-licensed under MIT or Apache-2.0.
