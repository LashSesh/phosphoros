use std::collections::HashMap;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Represents a single entity (wallet, validator, smart-contract) captured during ingestion.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EntityObservation {
    pub id: Uuid,
    pub address: String,
    pub features: Vec<f64>,
    #[serde(default)]
    pub connections: Vec<Uuid>,
    #[serde(default)]
    pub metadata: HashMap<String, serde_json::Value>,
}

impl EntityObservation {
    pub fn normalize(&mut self) {
        let norm = self
            .features
            .iter()
            .map(|value| value * value)
            .sum::<f64>()
            .sqrt()
            .max(f64::EPSILON);
        for value in &mut self.features {
            *value /= norm;
        }
    }
}

/// Raw ingestion payload accepted by the API.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotIngest {
    pub label: String,
    pub observations: Vec<EntityObservation>,
    #[serde(default)]
    pub context: HashMap<String, serde_json::Value>,
}

/// Stored snapshot enriched with timestamps and derived metadata.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotRecord {
    pub id: Uuid,
    pub label: String,
    pub captured_at: DateTime<Utc>,
    pub observations: Vec<EntityObservation>,
    #[serde(default)]
    pub context: HashMap<String, serde_json::Value>,
}

/// Request payload used to tune an analysis run.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisRequest {
    #[serde(default)]
    pub knn_k: Option<usize>,
    #[serde(default)]
    pub entropy_bins: Option<usize>,
    #[serde(default)]
    pub resonance_threshold: Option<f64>,
}

/// Result returned by the analytics pipeline.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisReport {
    pub snapshot_id: Uuid,
    pub label: String,
    pub captured_at: DateTime<Utc>,
    pub resonance_hotspots: Vec<ResonanceHotspot>,
    pub anomaly_scores: Vec<AnomalyScore>,
    pub topology: TopologySummary,
    pub entropy: EntropySummary,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceHotspot {
    pub origin: Uuid,
    pub magnitude: f64,
    pub neighbours: Vec<Uuid>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnomalyScore {
    pub entity: Uuid,
    pub z_score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TopologySummary {
    pub components: usize,
    pub articulation_points: usize,
    pub betti_estimate: Vec<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EntropySummary {
    pub spectral: f64,
    pub distribution: Vec<f64>,
}

impl SnapshotRecord {
    pub fn new(mut ingest: SnapshotIngest) -> Self {
        let id = Uuid::new_v4();
        let captured_at = Utc::now();
        for observation in &mut ingest.observations {
            observation.normalize();
        }
        SnapshotRecord {
            id,
            label: ingest.label,
            captured_at,
            observations: ingest.observations,
            context: ingest.context,
        }
    }
}
