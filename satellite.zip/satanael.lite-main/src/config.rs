use std::{fs, path::Path};

use serde::{Deserialize, Serialize};

/// Root configuration struct for the forensic satellite.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemConfig {
    #[serde(default)]
    pub api: ApiConfig,
    #[serde(default)]
    pub analysis: AnalysisConfig,
}

impl Default for SystemConfig {
    fn default() -> Self {
        Self {
            api: ApiConfig::default(),
            analysis: AnalysisConfig::default(),
        }
    }
}

impl SystemConfig {
    pub fn load_from_path<P: AsRef<Path>>(path: P) -> anyhow::Result<Self> {
        let raw = fs::read_to_string(path)?;
        let config: SystemConfig = if raw.trim_start().starts_with('{') {
            serde_json::from_str(&raw)?
        } else {
            serde_yaml::from_str(&raw)?
        };
        Ok(config)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiConfig {
    #[serde(default = "ApiConfig::default_host")]
    pub host: String,
    #[serde(default = "ApiConfig::default_port")]
    pub port: u16,
    #[serde(default)]
    pub cors_allowed_origins: Vec<String>,
}

impl Default for ApiConfig {
    fn default() -> Self {
        Self {
            host: Self::default_host(),
            port: Self::default_port(),
            cors_allowed_origins: vec![],
        }
    }
}

impl ApiConfig {
    fn default_host() -> String {
        "0.0.0.0".to_string()
    }

    fn default_port() -> u16 {
        8080
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisConfig {
    #[serde(default = "AnalysisConfig::default_knn_k")]
    pub knn_k: usize,
    #[serde(default = "AnalysisConfig::default_entropy_bins")]
    pub entropy_bins: usize,
    #[serde(default = "AnalysisConfig::default_resonance_threshold")]
    pub resonance_threshold: f64,
    #[serde(default = "AnalysisConfig::default_max_snapshots")]
    pub max_snapshots: usize,
}

impl Default for AnalysisConfig {
    fn default() -> Self {
        Self {
            knn_k: Self::default_knn_k(),
            entropy_bins: Self::default_entropy_bins(),
            resonance_threshold: Self::default_resonance_threshold(),
            max_snapshots: Self::default_max_snapshots(),
        }
    }
}

impl AnalysisConfig {
    const fn default_knn_k() -> usize {
        8
    }

    const fn default_entropy_bins() -> usize {
        16
    }

    const fn default_resonance_threshold() -> f64 {
        0.65
    }

    const fn default_max_snapshots() -> usize {
        32
    }
}
