use std::collections::{BTreeMap, VecDeque};

use parking_lot::RwLock;
use uuid::Uuid;

use crate::{config::AnalysisConfig, models::SnapshotRecord};

#[derive(Debug)]
pub struct ForensicState {
    snapshots: RwLock<BTreeMap<Uuid, SnapshotRecord>>,
    order: RwLock<VecDeque<Uuid>>,
    max_snapshots: usize,
}

impl ForensicState {
    pub fn new(config: &AnalysisConfig) -> Self {
        Self {
            snapshots: RwLock::new(BTreeMap::new()),
            order: RwLock::new(VecDeque::new()),
            max_snapshots: config.max_snapshots.max(1),
        }
    }

    pub fn insert(&self, snapshot: SnapshotRecord) -> Uuid {
        let id = snapshot.id;
        {
            let mut map = self.snapshots.write();
            map.insert(id, snapshot);
        }
        let mut order = self.order.write();
        order.push_back(id);
        while order.len() > self.max_snapshots {
            if let Some(removed) = order.pop_front() {
                self.snapshots.write().remove(&removed);
            }
        }
        id
    }

    pub fn list(&self) -> Vec<SnapshotRecord> {
        let map = self.snapshots.read();
        let mut snapshots: Vec<_> = map.values().cloned().collect();
        snapshots.sort_by_key(|record| record.captured_at);
        snapshots
    }

    pub fn get(&self, id: &Uuid) -> Option<SnapshotRecord> {
        self.snapshots.read().get(id).cloned()
    }
}
