use std::sync::Arc;

use anyhow::Context;
use parking_lot::RwLock;
use tracing::info;
use uuid::Uuid;

use crate::analysis::AnalyticsPipeline;
use crate::config::SystemConfig;
use crate::models::{AnalysisReport, AnalysisRequest, SnapshotIngest, SnapshotRecord};
use crate::state::ForensicState;

/// Central engine that orchestrates ingestion, analytics, and data retention.
#[derive(Debug)]
pub struct ForensicEngine {
    config: SystemConfig,
    pipeline: AnalyticsPipeline,
    state: Arc<ForensicState>,
    last_report: RwLock<Option<AnalysisReport>>,
}

impl ForensicEngine {
    pub fn new(config: SystemConfig) -> Self {
        let analysis_config = config.analysis.clone();
        let pipeline = AnalyticsPipeline::new(analysis_config.clone());
        let state = Arc::new(ForensicState::new(&analysis_config));
        Self {
            config,
            pipeline,
            state,
            last_report: RwLock::new(None),
        }
    }

    pub fn config(&self) -> &SystemConfig {
        &self.config
    }

    pub fn ingest(&self, ingest: SnapshotIngest) -> SnapshotRecord {
        let record = SnapshotRecord::new(ingest);
        let id = record.id;
        self.state.insert(record.clone());
        info!(snapshot_id = %id, "ingested snapshot");
        record
    }

    pub fn list_snapshots(&self) -> Vec<SnapshotRecord> {
        self.state.list()
    }

    pub fn analyze(&self, id: Uuid, request: AnalysisRequest) -> anyhow::Result<AnalysisReport> {
        let snapshot = self
            .state
            .get(&id)
            .with_context(|| format!("snapshot {id} not found"))?;
        let report = self.pipeline.run(&snapshot, request);
        *self.last_report.write() = Some(report.clone());
        Ok(report)
    }

    pub fn last_report(&self) -> Option<AnalysisReport> {
        self.last_report.read().clone()
    }

    pub fn state(&self) -> Arc<ForensicState> {
        Arc::clone(&self.state)
    }
}

impl Default for ForensicEngine {
    fn default() -> Self {
        Self::new(SystemConfig::default())
    }
}
