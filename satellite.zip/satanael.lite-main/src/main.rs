use std::{env, net::SocketAddr, sync::Arc};

use anyhow::Context;
use tokio::signal;
use tracing::{Level, info};
use tracing_subscriber::FmtSubscriber;

use satanael_lite::{ForensicEngine, build_router, config::SystemConfig};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let subscriber = FmtSubscriber::builder()
        .with_max_level(Level::INFO)
        .with_target(false)
        .finish();
    tracing::subscriber::set_global_default(subscriber).expect("failed to set tracing subscriber");

    let config = load_config().context("failed to load configuration")?;
    let address: SocketAddr = format!("{}:{}", config.api.host, config.api.port)
        .parse()
        .context("invalid bind address")?;

    let engine = Arc::new(ForensicEngine::new(config.clone()));
    let router = build_router(engine.clone());

    info!(%address, "starting Satanael Lite forensic satellite");
    let server = axum::serve(
        tokio::net::TcpListener::bind(address).await?,
        router.into_make_service_with_connect_info::<SocketAddr>(),
    );

    tokio::select! {
        result = server => {
            result.context("server error")?
        }
        _ = signal::ctrl_c() => {
            info!("received shutdown signal");
        }
    }

    if let Some(report) = engine.last_report() {
        info!(id = %report.snapshot_id, "last analysis report available");
    }

    Ok(())
}

fn load_config() -> anyhow::Result<SystemConfig> {
    if let Ok(path) = env::var("SATANAEL_CONFIG") {
        SystemConfig::load_from_path(path)
    } else {
        Ok(SystemConfig::default())
    }
}
